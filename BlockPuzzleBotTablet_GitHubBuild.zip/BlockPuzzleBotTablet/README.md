# Blok Bulmaca Botu — Android tablet prototipi

Bu klasör kaynak koddur; doğrudan kurulabilir APK değildir. GitHub Actions iş akışı eklenmiştir; GitHub'a yükleyip tablet tarayıcısından APK derletebilirsin. Derlenen APK test edilmeden oyunda doğru hamle yapacağı garanti edilemez.

## Bilgisayarsız APK oluşturma (tablet üzerinden)
1. GitHub hesabınla https://github.com/new adresinde yeni bir **Public** depo oluştur (ör. `blok-bulmaca-botu`).
2. ZIP'i tablette indirip aç. İçindeki `BlockPuzzleBotTablet` klasörünün **içeriğini** yeni depoya yükle; `.github` klasörünün de yüklendiğinden emin ol. GitHub web arayüzünde `Add file` → `Upload files` ile dosyaları yükleyebilirsin. Dosyaları klasör yapısını koruyarak yükle.
3. Yükleme bittikten sonra depoda **Actions** sekmesine gir. `Build Android APK` iş akışını seç ve `Run workflow` düğmesine bas.
4. İşlem yeşil tikle tamamlanınca çalıştırma kaydını aç. Sayfanın altındaki **Artifacts** bölümünden `BlockPuzzleBot-debug-apk` dosyasını indir.
5. ZIP içinden `app-debug.apk` dosyasını çıkar. Android'in soracağı durumda yalnızca kullandığın tarayıcı/dosya yöneticisi için bu dosyayı yükleme izni ver.

## Uygulamayı kullanma
1. APK'yı yükle ve aç.
2. Uygulamadaki erişilebilirlik ayarları düğmesine bas.
3. `Blok Bot ekran ve dokunma hizmeti` hizmetini etkinleştir.
4. Oyunu aç, sonra bot uygulamasına dönüp `Ekranı analiz et` seçeneğini kullan.
5. Algılama doğru görünüyorsa `Bir hamle yap` seçeneğini dene. İlk denemede yanlış hamle ihtimaline karşı oyun ilerlemesini kontrol et.

## Sınırlamalar
- Bu ilk prototip tek hamle önerip sürükleme denemesi yapar; tam otomatik oyun/bölüm geçişi değildir.
- Algılama koordinatları belirli bir ekran görüntüsüne göre yaklaşık ayarlanmıştır; farklı çözünürlük, yön veya oyun düzeninde hata yapabilir.
- Oyunun ekran yakalamayı engellemesi halinde analiz çalışmayabilir.
- GitHub Actions derleme hatası verirse `Actions` kaydındaki hata metni gerekir. Başarılı derleme, botun oyun içinde doğru çalıştığını tek başına kanıtlamaz.
