package com.ilyas.blockbot;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 40, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setBackgroundColor(0xFFF1F3FF);
        TextView title = new TextView(this);
        title.setText("BLOK BULMACA BOTU");
        title.setTextSize(24);
        title.setTextColor(0xFF20264A);
        title.setPadding(0, 8, 0, 24);
        layout.addView(title);
        TextView info = new TextView(this);
        info.setText("Bu ilk tablet prototipi, ekranı okuyup bir hamle önerir. Doğru algılama kontrol edilmeden otomatik hamleyi kullanma.");
        info.setTextSize(16);
        info.setTextColor(0xFF30354F);
        info.setPadding(0, 0, 0, 24);
        layout.addView(info);
        Button accessibility = new Button(this);
        accessibility.setText("1. Erişilebilirlik hizmetini aç");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(accessibility, fullWidth());
        Button analyze = new Button(this);
        analyze.setText("2. Ekranı analiz et");
        analyze.setOnClickListener(v -> {
            PuzzleAccessibilityService svc = PuzzleAccessibilityService.instance;
            if (svc == null) setStatus("Önce erişilebilirlik ayarlarından Blok Bot hizmetini etkinleştir.");
            else svc.analyzeOnly();
        });
        layout.addView(analyze, fullWidth());
        Button move = new Button(this);
        move.setText("3. Bir hamle yap");
        move.setOnClickListener(v -> {
            PuzzleAccessibilityService svc = PuzzleAccessibilityService.instance;
            if (svc == null) setStatus("Erişilebilirlik hizmeti etkin değil.");
            else svc.analyzeAndMove();
        });
        layout.addView(move, fullWidth());
        status = new TextView(this);
        status.setText("Durum: Hazır");
        status.setTextSize(16);
        status.setTextColor(0xFF20264A);
        status.setPadding(0, 24, 0, 0);
        layout.addView(status);
        setContentView(layout);
    }
    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
    private void setStatus(String s) {
        status.setText("Durum: " + s);
    }
}
