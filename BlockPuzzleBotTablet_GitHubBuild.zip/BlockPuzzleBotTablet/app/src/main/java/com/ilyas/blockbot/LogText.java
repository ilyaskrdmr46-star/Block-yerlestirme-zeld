package com.ilyas.blockbot;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

final class LogText {
    static void show(Context c, String message) {
        new Handler(Looper.getMainLooper()).post(() ->
            Toast.makeText(c, message, Toast.LENGTH_LONG).show());
    }
}
