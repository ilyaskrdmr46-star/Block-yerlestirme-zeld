package com.ilyas.blockbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PuzzleAccessibilityService extends AccessibilityService {
    public static volatile PuzzleAccessibilityService instance;
    private static final int N = 8;
    private static final double REF_W = 917.0, REF_H = 2048.0;
    private static final double BX = 102, BY = 299, BW = 713, BH = 713;
    // Approximate centers of the tray cells in the supplied screenshot.
    private static final double[] TX = {390, 424, 458, 492, 526};
    private static final double[] TY = {1269, 1303, 1337};
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public void analyzeOnly() { capture(false); }
    public void analyzeAndMove() { capture(true); }

    private void capture(boolean doMove) {
        if (android.os.Build.VERSION.SDK_INT < 30) {
            LogText.show(this, "Android 11 veya üstü gerekiyor.");
            return;
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult result) {
                try {
                    Bitmap b = Bitmap.wrapHardwareBuffer(result.getHardwareBuffer(), result.getColorSpace());
                    if (b == null) { LogText.show(PuzzleAccessibilityService.this, "Ekran görüntüsü alınamadı."); return; }
                    Bitmap copy = b.copy(Bitmap.Config.ARGB_8888, false);
                    result.getHardwareBuffer().close();
                    analyzeBitmap(copy, doMove);
                } catch (Throwable t) {
                    Log.e("BlockBot", "Screenshot processing failed", t);
                    LogText.show(PuzzleAccessibilityService.this, "Ekran analiz hatası: " + t.getMessage());
                }
            }
            @Override public void onFailure(int errorCode) {
                LogText.show(PuzzleAccessibilityService.this, "Ekran yakalama başarısız. Hata: " + errorCode);
            }
        });
    }

    private void analyzeBitmap(Bitmap bmp, boolean doMove) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        boolean[][] board = new boolean[N][N];
        double cellW = BW / N * w / REF_W, cellH = BH / N * h / REF_H;
        for (int r=0;r<N;r++) for (int c=0;c<N;c++) {
            int x=(int)((BX+(c+.5)*BW/N)*w/REF_W), y=(int)((BY+(r+.5)*BH/N)*h/REF_H);
            board[r][c] = orangeAt(bmp,x,y,(int)(Math.min(cellW,cellH)*.22));
        }
        List<int[]> raw = new ArrayList<>();
        for (int r=0;r<TY.length;r++) for (int c=0;c<TX.length;c++) {
            int x=(int)(TX[c]*w/REF_W), y=(int)(TY[r]*h/REF_H);
            if (orangeAt(bmp,x,y,Math.max(4,(int)(8*Math.min(w/REF_W,h/REF_H))))) raw.add(new int[]{r,c});
        }
        if (raw.isEmpty()) {
            LogText.show(this, "Parça bulunamadı. Oyun düzeni/ekran ölçeği farklı olabilir.");
            return;
        }
        int minR=9,minC=9;
        for (int[] p:raw) { minR=Math.min(minR,p[0]); minC=Math.min(minC,p[1]); }
        List<int[]> piece = new ArrayList<>();
        for (int[] p:raw) piece.add(new int[]{p[0]-minR,p[1]-minC});
        int ph=0,pw=0;
        for(int[] p:piece){ph=Math.max(ph,p[0]+1);pw=Math.max(pw,p[1]+1);}
        int bestR=-1,bestC=-1,bestScore=Integer.MIN_VALUE;
        for(int top=0;top<=N-ph;top++) for(int left=0;left<=N-pw;left++) {
            boolean ok=true;
            for(int[] p:piece) if(board[top+p[0]][left+p[1]]) {ok=false;break;}
            if(!ok) continue;
            boolean[][] next=new boolean[N][N];
            for(int r=0;r<N;r++) System.arraycopy(board[r],0,next[r],0,N);
            for(int[] p:piece) next[top+p[0]][left+p[1]]=true;
            int full=0;
            for(int r=0;r<N;r++){boolean all=true;for(int c=0;c<N;c++)all&=next[r][c];if(all)full++;}
            for(int c=0;c<N;c++){boolean all=true;for(int r=0;r<N;r++)all&=next[r][c];if(all)full++;}
            int score=full*1000+top;
            if(score>bestScore){bestScore=score;bestR=top;bestC=left;}
        }
        if(bestR<0) {
            LogText.show(this, "Bu parça için uygun yer bulunamadı.");
            return;
        }
        String message=String.format(Locale.US,"Algılanan parça: %d kare. Öneri: satır %d, sütun %d.",piece.size(),bestR+1,bestC+1);
        LogText.show(this,message);
        if(!doMove) return;

        // Drag from the top-left detected tray tile to the matching destination cell.
        int sourceX=(int)(TX[minC]*w/REF_W), sourceY=(int)(TY[minR]*h/REF_H);
        int destX=(int)((BX+(bestC+.5)*BW/N)*w/REF_W);
        int destY=(int)((BY+(bestR+.5)*BH/N)*h/REF_H);
        Path path=new Path(); path.moveTo(sourceX,sourceY); path.lineTo(destX,destY);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,650);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){LogText.show(PuzzleAccessibilityService.this,"Sürükleme gönderildi. Ekranı kontrol et.");}
            @Override public void onCancelled(GestureDescription g){LogText.show(PuzzleAccessibilityService.this,"Sürükleme iptal edildi.");}
        },null);
    }

    private boolean orangeAt(Bitmap b,int cx,int cy,int radius) {
        int x0=Math.max(0,cx-radius),x1=Math.min(b.getWidth()-1,cx+radius);
        int y0=Math.max(0,cy-radius),y1=Math.min(b.getHeight()-1,cy+radius);
        if(x1<=x0||y1<=y0)return false;
        int hits=0,total=0;
        for(int y=y0;y<=y1;y+=2) for(int x=x0;x<=x1;x+=2) {
            int color=b.getPixel(x,y); float[] hsv=new float[3]; Color.colorToHSV(color,hsv);
            boolean orange=(hsv[0]<=22 || hsv[0]>=170) && hsv[1]>=0.35f && hsv[2]>=0.35f;
            if(orange)hits++; total++;
        }
        return total>0 && ((double)hits/total)>0.12;
    }
}
